# Phonology Battle: USA Edition

A real-time multiplayer browser quiz for 15–30 students, built with Node.js, Express and Socket.IO. The original 20 questions and their answer keys are preserved.

## Included features
- Teacher creates a room and shares a six-character code.
- Students join from their phones using the same public website URL.
- 20 questions on phonological theory, IPA, US English sound patterns, sociophonetics and speech technology.
- Server-controlled 20-second timer, one answer per question, up to 1,000 points for correct fast answers.
- Live answer count and leaderboard, explanations, and final podium.
- Black, white and green design.

## Publish online with Render
This project includes `render.yaml` for Render's deployment configuration. To publish it, you must connect a GitHub repository to your own Render account; this archive alone cannot create a public URL.

1. Extract this ZIP.
2. Create a GitHub repository and upload the **contents** of the `phonology_battle` folder to the repository root (`server.js`, `package.json`, `render.yaml`, and `public/`).
3. Sign in to Render and choose **New + → Blueprint** (or create a Web Service connected to the repository).
4. If using Blueprint, Render reads `render.yaml`; review the service and deploy it. If creating a Web Service manually, use Build Command `npm install` and Start Command `npm start`.
5. After deployment, copy the public HTTPS URL. Open it, enter the teacher name, and click **Create room**. Share that same URL and the six-character room code with students.

A free service may sleep after inactivity, so open the site a little before class to allow it to wake up. Keep the teacher tab open for the entire game. Room state and scores are stored in server memory; restarting the service clears active rooms. If the teacher disconnects, the room closes.

## Run locally
Requires Node.js 18+.

```bash
npm install
npm start
```

Open http://localhost:3000.

## Questions
The 20 questions are defined in the `Q` array near the top of `server.js`. Each entry contains the question, four options, the zero-based index of the correct option, and an explanation.
